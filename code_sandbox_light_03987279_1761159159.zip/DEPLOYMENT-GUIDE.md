# Cloudflare Pages Deployment Guide

## Your Website Files
You need to deploy these files to Cloudflare Pages:
- index.html
- css/style.css
- js/main.js

## Method 1: Direct Upload via Cloudflare Dashboard

1. **Go to Cloudflare Pages Dashboard**
   - Visit: https://dash.cloudflare.com/
   - Navigate to: Workers & Pages → Create application → Pages

2. **Upload Your Files**
   - Choose "Upload assets"
   - Click "Create project"
   - Name it: powerpath-partners
   - Drag and drop your files (maintain folder structure):
     ```
     index.html
     css/style.css
     js/main.js
     ```

3. **Deploy**
   - Click "Deploy site"
   - Wait for deployment (usually 1-2 minutes)

4. **Connect Custom Domain**
   - In your project settings → Custom domains
   - Click "Set up a custom domain"
   - Enter: powerpath-partners.com
   - Cloudflare will automatically configure DNS (since your domain is already on Cloudflare)

---

## Method 2: Using Wrangler CLI (Command Line)

If you have terminal access:

```bash
# Install Wrangler
npm install -g wrangler

# Login with your API token
wrangler login

# Deploy to Cloudflare Pages
wrangler pages publish . --project-name=powerpath-partners

# Add custom domain
wrangler pages deployment tail powerpath-partners
```

---

## Method 3: Git Integration (Best for Updates)

1. **Create GitHub Repository**
   - Upload your files to GitHub
   - Keep the folder structure

2. **Connect to Cloudflare Pages**
   - In Cloudflare Dashboard: Workers & Pages → Create
   - Choose "Connect to Git"
   - Select your repository
   - Build settings:
     - Build command: (leave empty)
     - Build output directory: /
   - Deploy!

3. **Custom Domain**
   - Automatically use powerpath-partners.com
   - Cloudflare handles DNS

---

## DNS Configuration (If Needed)

Your domain powerpath-partners.com should already be on Cloudflare.

**If you need to manually configure DNS:**

1. Go to Cloudflare Dashboard → Your domain → DNS
2. Add CNAME record:
   - Type: CNAME
   - Name: @ (or powerpath-partners.com)
   - Target: [your-project].pages.dev
   - Proxy status: Proxied (orange cloud)

---

## Verification

After deployment, your site will be live at:
- Main: https://powerpath-partners.com
- Cloudflare: https://powerpath-partners.pages.dev

---

## Quick Checklist

- [ ] Files uploaded to Cloudflare Pages
- [ ] Project deployed successfully
- [ ] Custom domain connected
- [ ] DNS configured (usually automatic)
- [ ] SSL certificate active (automatic with Cloudflare)
- [ ] Website accessible at powerpath-partners.com

---

## Troubleshooting

**Issue: Domain not connecting**
- Wait 5-10 minutes for DNS propagation
- Check DNS records in Cloudflare dashboard
- Ensure domain is active in Cloudflare

**Issue: Files not loading**
- Verify folder structure is correct
- Check that css/ and js/ folders exist
- Ensure file paths are correct

**Issue: SSL errors**
- Cloudflare provides automatic SSL
- May take a few minutes to activate
- Check SSL/TLS settings: Full or Full (strict)

---

## Need Help?

If you encounter issues:
1. Check Cloudflare Pages logs
2. Verify your API token has correct permissions
3. Ensure domain is active on Cloudflare
4. Check deployment status in dashboard
